package theater.beans;

public class Preisklasse {

}
