package theater.beans;

public class Karte {

}
