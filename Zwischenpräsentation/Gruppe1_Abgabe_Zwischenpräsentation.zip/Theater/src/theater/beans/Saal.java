package theater.beans;

public class Saal {

}
