package theater.beans;

public class Sitzplatz {

}
