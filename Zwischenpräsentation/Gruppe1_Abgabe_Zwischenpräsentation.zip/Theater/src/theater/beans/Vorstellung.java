package theater.beans;

public class Vorstellung {

}
