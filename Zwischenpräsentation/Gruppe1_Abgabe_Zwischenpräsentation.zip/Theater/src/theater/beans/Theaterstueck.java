package theater.beans;

public class Theaterstueck {

}
